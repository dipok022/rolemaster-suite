<?php

// pretty_log('upgrader 1.0.1', 'is running.............');
// pretty_log('ROLEMASTER_BASE', ROLEMASTER_BASE);
// pretty_log('ROLEMASTER_DIR', ROLEMASTER_DIR);
